<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Mail;

class Question extends Model
{

    public static function storeQuestion($author, $email, $text)
    {
        $question = new Question();
        $question->author = $author;
        $question->email = $email;
        $question->question = $text;
        $question->save();

        $settings = Settings::find(1);

        $message = 'There is a new question from ' . $author . ', email - ' . $email . ', question - ' . $text;
        Question::mail('New message',$settings->admin_email, $message);

        return $question->id;
    }

    public function getFiles()
    {
        return $this->morphMany('App\File', 'owner');
    }

    public static function mail(string $theme,string $email,string $text)
    {
        $data = array('text'=>$text);

        Mail::send('emails.question', $data, function($message) {
            $settings = Settings::find(1);
            $message->to($settings->admin_email, 'Dear Client')->subject
            ('New message');
            $message->from('kopose@yandex.ru','Kopose');
        });
    }
}
