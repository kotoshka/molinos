<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="block">
                <div class="navbar navbar-inner block-header">
                    <div class="muted pull-left">Form Example</div>
                </div>
                <div class="block-content collapse in">
                    <div class="span12">
                        <form class="form-horizontal" method="post" action="<?php echo e(route('questions.store')); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <fieldset>
                                <legend>Callback form </legend>
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php if(isset( Request()->message)): ?>
                                    <span style="color: green"><?php echo e(Request()->message); ?></span>
                                <?php else: ?>
                                    <div class="form-wrapper">
                                        <div class="form-col">
                                            <div class="control-group">
                                                <label class="control-label" for="author">Name</label>
                                                <div class="controls">
                                                    <input class="input-xlarge" id="author" name="author" type="text" placeholder="Enter name ..." value="<?php echo e(old('author')); ?>">
                                                </div>
                                            </div>
                                            <div class="control-group">
                                                <label class="control-label" for="email">Email</label>
                                                <div class="controls">
                                                    <input class="input-xlarge" id="email" name="email" type="text" placeholder="Enter email ..." value="<?php echo e(old('email')); ?>">
                                                </div>
                                            </div>
                                            <div class="control-group">
                                                <label class="control-label" for="question">Question</label>
                                                <div class="controls">
                                                    <textarea class="input-xlarge textarea" id="question" name="question" rows="8" placeholder="Enter text ..."><?php echo e(old('question')); ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-col">
                                            <div class="">
                                                <label for="uploadbtn" class="no-m">
                                                    File
                                                </label>
                                            </div>
                                            <label for="uploadbtn" class="no-m">
                                                <div class="control-group form-border">
                                                    <p class="gray-text"> Drop files here or click to upload...</p>
                                                    <div id="drop-files" class="full-width" ondragover="return false">
                                                        <input type="file" name="file[]" id="uploadbtn" class="hidden-input" multiple />
                                                    </div>
                                                    <div id="uploaded-holder">
                                                        <div id="dropped-files">
                                                        </div>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-actions">
                                        <button type="submit" class="btn btn-large btn-primary">Send</button>
                                    </div>
                                <?php endif; ?>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.no-sidebar-app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>