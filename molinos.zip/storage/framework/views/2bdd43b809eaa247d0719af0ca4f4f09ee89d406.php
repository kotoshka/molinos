<?php $__env->startSection('content'); ?>
    <div class="row-fluid">
        <div class="block no-m">
            <div class="navbar navbar-inner block-header">
                <div class="muted pull-left">List of applications</div>
            </div>
            <div class="block-content collapse in">
                <div class="span12">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Question</th>
                            <th>Files</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div><?php echo e($key + 1); ?></div>
                                        <div class="delete-item">
                                            <a href="<?php echo e(route('questions.delete', ['question_id' => $question->id])); ?>">
                                                Delete
                                            </a>
                                        </div>
                                        <div class="answer-item">
                                            <a href="<?php echo e(route('questions.answer', ['question_id' => $question->id])); ?>">
                                                Answer
                                            </a>
                                        </div>
                                    </td>
                                    <td><?php echo e($question->author); ?></td>
                                    <td><?php echo e($question->email); ?></td>
                                    <td><?php echo e($question->question); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $question->getFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img width="100px" src="<?php echo e('/images/'.$file->name); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                                <?php if(isset($question->answer)): ?>
                                    <tr class="answers">
                                        <td colspan="5">
                                            ANSWER: <?php echo e($question->answer); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>