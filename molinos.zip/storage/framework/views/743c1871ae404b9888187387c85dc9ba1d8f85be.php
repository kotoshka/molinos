<?php $__env->startSection('content'); ?>
    <div class="row-fluid">
        <div class="block no-m">
            <div class="navbar navbar-inner block-header">
                <div class="muted pull-left">Settings</div>
            </div>
            <div class="block-content collapse in">
                <div class="span12">
                    <form class="form-horizontal" method="post" action="<?php echo e(route('admin.edit')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <fieldset>
                            <legend>Change site settings here</legend>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <div class="control-group">
                                <label class="control-label" for="site_name">Site name</label>
                                <div class="controls">
                                    <input type="text" class="input-xlarge" id="site_name" name="site_name" value="<?php echo e($settings->site_name); ?>">
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="admin_email">Admin email</label>
                                <div class="controls">
                                    <input type="text" class="input-xlarge" id="admin_email" name="admin_email" value="<?php echo e($settings->admin_email); ?>">
                                </div>
                            </div>
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary">Save changes</button>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>